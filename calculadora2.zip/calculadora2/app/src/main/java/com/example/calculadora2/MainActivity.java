package com.example.calculadora2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity<Botton> extends AppCompatActivity {

    EditText numero1
    EditText numero2
    TextView resultado
     Botton suma
     Botton resta
     Botton dividir
     Botton multiplicar


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero1 = (EditText) findViewById(R.id.numero1);
        numero2 = (EditText) findViewById(R.id.numero2);
        resultado = (EditText) findViewById(R.id.resultado);


    }
    public void Suma (View View){
        double
    }
    public void Dividir (View View) {
        double
      valor1= double.
        double
    }
}